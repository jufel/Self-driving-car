import numpy as np
import tensorflow as tf
import os

class Model:

    saved_speed_model = 'speed_model/'
    saved_angle_model = 'angle_model/'
    saved_signal_model = 'signal_model/'
    
    def __init__(self):
        self.speed_model = tf.keras.models.load_model(os.path.join(os.path.dirname(os.path.abspath(__file__)), self.saved_speed_model))
        self.angle_model = tf.keras.models.load_model(os.path.join(os.path.dirname(os.path.abspath(__file__)), self.saved_angle_model))
        self.signal_model = tf.keras.models.load_model(os.path.join(os.path.dirname(os.path.abspath(__file__)), self.saved_signal_model))

    def preprocess(self, image):
        img = tf.image.convert_image_dtype(image, tf.float32)
        img = tf.image.resize(img,(224, 224))
        img = tf.reshape(img,(1,224,224,3))
        return img

    def predict(self, image):
        image = self.preprocess(image)
        angle_value = self.angle_model.predict(image)[0][0]
        speed_value = self.speed_model.predict(image)[0][0]
        signal_value = self.signal_model.predict(image)[0]
        
        if max(signal_value) != signal_value[0]:
            if abs(signal_value[1]-signal_value[2]) > 0.1:
                if signal_value[1] > signal_value[2]:
                    speed = 1
                else:
                    speed = 0
            else:
                speed = speed_value
        else:
            speed = speed_value
        if abs((1 - speed)) < abs((0-speed)):
            speed = 30
        else:
            speed = 0
        angle = angle_value * 80 + 50
        angle = 5 * round(angle/5)
        if angle < 50:
            angle = 50
        if angle > 130:
            angle = 130

        print('angle:', angle,'speed:', speed)
        
        return angle, speed
